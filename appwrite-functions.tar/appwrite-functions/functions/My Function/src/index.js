const sdk = require("node-appwrite");

/*
  'req' variable has:
    'headers' - object with request headers
    'payload' - request body data as a string
    'variables' - object with function variables

  'res' variable has:
    'send(text, status)' - function to return text response. Status code defaults to 200
    'json(obj, status)' - function to return JSON response. Status code defaults to 200

  If an error is thrown, a response with code 500 will be returned.
*/

module.exports = async function (req, res, log, error) {
  const client = new sdk.Client();

  log("raw body req", req.bodyRaw); // Raw request body, contains request data
  log("JSON.stringyfy body", JSON.stringify(req.body)); // Object from parsed JSON request body, otherwise string
  log("JSON.stringyfy body", JSON.stringify(req.headers)); // String key-value pairs of all request headers, keys are lowercase
  log("schme", req.scheme); // Value of the x-forwarded-proto header, usually http or https
  log("method", req.method); // Request method, such as GET, POST, PUT, DELETE, PATCH, etc.
  log("url", req.url); // Full URL, for example: http://awesome.appwrite.io:8000/v1/hooks?limit=12&offset=50
  log("hostname", req.host); // Hostname from the host header, such as awesome.appwrite.io
  log("port number", req.port); // Port from the host header, for example 8000
  log("req path", req.path); // Path part of URL, for example /v1/hooks
  log("query string", req.queryString); // Raw query params string. For example "limit=12&offset=50"
  log("JSON query", JSON.stringify(req.query)); // Parsed query params. For example, req.query.limit

  return res.send(
    "All the request parameters are logged to the Appwrite Console."
  );
};
